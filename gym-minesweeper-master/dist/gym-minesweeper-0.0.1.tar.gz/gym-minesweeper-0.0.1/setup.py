from setuptools import setup

setup(name='gym_minesweeper',
    version='0.0.1',
    install_requires=['gym>=0.24.1', 'pygame>=2.1.2']
)